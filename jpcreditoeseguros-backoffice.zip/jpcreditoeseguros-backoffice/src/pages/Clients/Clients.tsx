import { WorkInProgress } from "../../components/work-in-progress/WorkInProgress";

export const Clients = () => {
  return <WorkInProgress />;
};
