import { BankCounterDetails } from "../../components/BankCounterDetails/BankCounterDetails";

export const BankCounterEdition = () => {
  const handleEditSave = () => null;

  return <BankCounterDetails onSave={handleEditSave} />;
};
