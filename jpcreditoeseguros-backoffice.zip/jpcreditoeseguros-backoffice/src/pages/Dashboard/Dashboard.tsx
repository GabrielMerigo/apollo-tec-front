import { WorkInProgress } from "../../components/work-in-progress/WorkInProgress";

export const Dashboard = () => {
  return (
    <div className="d-flex">
      <WorkInProgress />
    </div>
  );
};
