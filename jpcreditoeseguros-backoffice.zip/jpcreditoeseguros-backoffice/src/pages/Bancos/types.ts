export interface Bank {
    id: number;
    name: string;
    notes: string;
    phone: string;
    website: string;
  }