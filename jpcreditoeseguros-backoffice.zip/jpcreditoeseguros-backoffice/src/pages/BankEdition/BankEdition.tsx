import { BankDetails } from "../../components/BankDetails/BankDetails";

export const BankEdition = () => {
  return <BankDetails />;
};
