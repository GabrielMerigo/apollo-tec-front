## Descrição das Mudanças

<!--
Descrever em poucas palavras o que essa branch pretende implementar na branch destino
-->

## Evidências (Se aplicável) (Gravação ou printscreen mostrando a feature/correção)

## Checklist (Questionário de PR)

- [ ] A UI se assemelha ao design correspondente no Figma
- [ ] Não há nenhum erro no console do navegador
- [ ] Linters não exibem erros
- [ ] Essa branch independe de qualquer outra mudança para ser feito o merge
- [ ] Essa branch representa a implementação de uma só tarefa/subtarefa

## Exceções

Justificativa para checkboxes não selecionadas:

<!--
## Instruções
- Título da PR deve seguir este padrão: ALE-123: Título da tarefa`
- Incluir o link da tarefa do Jira
-->
